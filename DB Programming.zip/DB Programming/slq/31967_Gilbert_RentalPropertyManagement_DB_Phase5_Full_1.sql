-- ============================================================
-- Project: 31967_Gilbert_RentalPropertyManagement_DB
-- Student: Gilbert (ID: 31967/2025)
-- Phase V: Full reset + Table Implementation (run this whole file at once)
-- ============================================================

-- ------------------------------------------------------------
-- STEP 0: Drop old tables if they exist (ignore "does not exist" errors)

-- ------------------------------------------------------------
-- 1. LANDLORD
-- ------------------------------------------------------------
CREATE TABLE landlord (
    landlord_id     NUMBER          GENERATED ALWAYS AS IDENTITY,
    first_name      VARCHAR2(50)    NOT NULL,
    last_name       VARCHAR2(50)    NOT NULL,
    phone           VARCHAR2(20)    NOT NULL,
    email           VARCHAR2(100),
    CONSTRAINT pk_landlord PRIMARY KEY (landlord_id),
    CONSTRAINT uq_landlord_phone UNIQUE (phone)
);

-- ------------------------------------------------------------
-- 2. PROPERTY
-- ------------------------------------------------------------
CREATE TABLE property (
    property_id     NUMBER          GENERATED ALWAYS AS IDENTITY,
    landlord_id     NUMBER          NOT NULL,
    property_name   VARCHAR2(100)   NOT NULL,
    address         VARCHAR2(150)   NOT NULL,
    city            VARCHAR2(50)    NOT NULL,
    property_type   VARCHAR2(20)    NOT NULL,
    CONSTRAINT pk_property PRIMARY KEY (property_id),
    CONSTRAINT fk_property_landlord FOREIGN KEY (landlord_id)
        REFERENCES landlord (landlord_id),
    CONSTRAINT chk_property_type CHECK (property_type IN ('Residential', 'Commercial'))
);

-- ------------------------------------------------------------
-- 3. UNIT
-- ------------------------------------------------------------
CREATE TABLE unit (
    unit_id         NUMBER          GENERATED ALWAYS AS IDENTITY,
    property_id     NUMBER          NOT NULL,
    unit_number     VARCHAR2(20)    NOT NULL,
    unit_type       VARCHAR2(30)    NOT NULL,
    monthly_rent    NUMBER(10,2)    NOT NULL,
    status          VARCHAR2(20)    DEFAULT 'Vacant' NOT NULL,
    CONSTRAINT pk_unit PRIMARY KEY (unit_id),
    CONSTRAINT fk_unit_property FOREIGN KEY (property_id)
        REFERENCES property (property_id),
    CONSTRAINT chk_unit_status CHECK (status IN ('Vacant', 'Occupied', 'Maintenance')),
    CONSTRAINT chk_unit_rent CHECK (monthly_rent > 0),
    CONSTRAINT uq_unit_per_property UNIQUE (property_id, unit_number)
);

-- ------------------------------------------------------------
-- 4. TENANT
-- ------------------------------------------------------------
CREATE TABLE tenant (
    tenant_id       NUMBER          GENERATED ALWAYS AS IDENTITY,
    first_name      VARCHAR2(50)    NOT NULL,
    last_name       VARCHAR2(50)    NOT NULL,
    phone           VARCHAR2(20)    NOT NULL,
    national_id     VARCHAR2(30)    NOT NULL,
    CONSTRAINT pk_tenant PRIMARY KEY (tenant_id),
    CONSTRAINT uq_tenant_national_id UNIQUE (national_id)
);

-- ------------------------------------------------------------
-- 5. LEASE_AGREEMENT
-- ------------------------------------------------------------
CREATE TABLE lease_agreement (
    lease_id        NUMBER          GENERATED ALWAYS AS IDENTITY,
    unit_id         NUMBER          NOT NULL,
    tenant_id       NUMBER          NOT NULL,
    start_date      DATE            NOT NULL,
    end_date        DATE            NOT NULL,
    monthly_rent    NUMBER(10,2)    NOT NULL,
    deposit_amount  NUMBER(10,2)    DEFAULT 0,
    status          VARCHAR2(20)    DEFAULT 'Active' NOT NULL,
    CONSTRAINT pk_lease PRIMARY KEY (lease_id),
    CONSTRAINT fk_lease_unit FOREIGN KEY (unit_id)
        REFERENCES unit (unit_id),
    CONSTRAINT fk_lease_tenant FOREIGN KEY (tenant_id)
        REFERENCES tenant (tenant_id),
    CONSTRAINT chk_lease_dates CHECK (end_date > start_date),
    CONSTRAINT chk_lease_status CHECK (status IN ('Active', 'Expired', 'Terminated'))
);

-- ------------------------------------------------------------
-- 6. PAYMENT
-- ------------------------------------------------------------
CREATE TABLE payment (
    payment_id      NUMBER          GENERATED ALWAYS AS IDENTITY,
    lease_id        NUMBER          NOT NULL,
    payment_date    DATE            DEFAULT SYSDATE NOT NULL,
    amount          NUMBER(10,2)    NOT NULL,
    payment_method  VARCHAR2(20)    NOT NULL,
    recorded_by     VARCHAR2(50),
    CONSTRAINT pk_payment PRIMARY KEY (payment_id),
    CONSTRAINT fk_payment_lease FOREIGN KEY (lease_id)
        REFERENCES lease_agreement (lease_id),
    CONSTRAINT chk_payment_amount CHECK (amount > 0),
    CONSTRAINT chk_payment_method CHECK (payment_method IN ('Cash', 'Mobile Money', 'Bank Transfer'))
);

-- ------------------------------------------------------------
-- 7. MAINTENANCE_REQUEST
-- ------------------------------------------------------------
CREATE TABLE maintenance_request (
    request_id      NUMBER          GENERATED ALWAYS AS IDENTITY,
    unit_id         NUMBER          NOT NULL,
    tenant_id       NUMBER          NOT NULL,
    description     VARCHAR2(200)   NOT NULL,
    date_reported   DATE            DEFAULT SYSDATE NOT NULL,
    status          VARCHAR2(20)    DEFAULT 'Open' NOT NULL,
    date_resolved   DATE,
    assigned_staff  VARCHAR2(50),
    CONSTRAINT pk_maintenance PRIMARY KEY (request_id),
    CONSTRAINT fk_maintenance_unit FOREIGN KEY (unit_id)
        REFERENCES unit (unit_id),
    CONSTRAINT fk_maintenance_tenant FOREIGN KEY (tenant_id)
        REFERENCES tenant (tenant_id),
    CONSTRAINT chk_maintenance_status CHECK (status IN ('Open', 'In-Progress', 'Resolved'))
);

-- ------------------------------------------------------------
-- 8. PUBLIC_HOLIDAY
-- ------------------------------------------------------------
CREATE TABLE public_holiday (
    holiday_id      NUMBER          GENERATED ALWAYS AS IDENTITY,
    holiday_date    DATE            NOT NULL,
    description     VARCHAR2(100)   NOT NULL,
    CONSTRAINT pk_holiday PRIMARY KEY (holiday_id),
    CONSTRAINT uq_holiday_date UNIQUE (holiday_date)
);

-- ------------------------------------------------------------
-- 9. AUDIT_LOG
-- ------------------------------------------------------------
CREATE TABLE audit_log (
    audit_id        NUMBER          GENERATED ALWAYS AS IDENTITY,
    table_name      VARCHAR2(30)    NOT NULL,
    operation       VARCHAR2(10)    NOT NULL,
    user_name       VARCHAR2(50)    NOT NULL,
    action_timestamp TIMESTAMP      DEFAULT SYSTIMESTAMP NOT NULL,
    old_value       VARCHAR2(4000),
    new_value       VARCHAR2(4000),
    CONSTRAINT pk_audit PRIMARY KEY (audit_id),
    CONSTRAINT chk_audit_operation CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE'))
);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

INSERT INTO landlord (first_name, last_name, phone, email)
VALUES ('Jean', 'Uwimana', '0788123456', 'jean.uwimana@example.com');

INSERT INTO landlord (first_name, last_name, phone, email)
VALUES ('Marie', 'Mukamana', '0788654321', 'marie.mukamana@example.com');

INSERT INTO property (landlord_id, property_name, address, city, property_type)
VALUES (1, 'Kigali Heights Apartments', 'KG 7 Ave, Kacyiru', 'Kigali', 'Residential');

INSERT INTO property (landlord_id, property_name, address, city, property_type)
VALUES (2, 'Remera Business Plaza', 'KG 11 St, Remera', 'Kigali', 'Commercial');

INSERT INTO unit (property_id, unit_number, unit_type, monthly_rent, status)
VALUES (1, 'A1', '2-Bedroom', 250000, 'Occupied');

INSERT INTO unit (property_id, unit_number, unit_type, monthly_rent, status)
VALUES (1, 'A2', 'Studio', 150000, 'Vacant');

INSERT INTO unit (property_id, unit_number, unit_type, monthly_rent, status)
VALUES (2, 'B1', 'Office', 400000, 'Occupied');

INSERT INTO tenant (first_name, last_name, phone, national_id)
VALUES ('Eric', 'Habimana', '0722334455', '1198012345678901');

INSERT INTO tenant (first_name, last_name, phone, national_id)
VALUES ('Alice', 'Niyonsaba', '0733445566', '1198098765432109');

INSERT INTO lease_agreement (unit_id, tenant_id, start_date, end_date, monthly_rent, deposit_amount, status)
VALUES (1, 1, DATE '2026-01-01', DATE '2026-12-31', 250000, 500000, 'Active');

INSERT INTO lease_agreement (unit_id, tenant_id, start_date, end_date, monthly_rent, deposit_amount, status)
VALUES (3, 2, DATE '2026-02-01', DATE '2027-01-31', 400000, 800000, 'Active');

INSERT INTO payment (lease_id, payment_date, amount, payment_method, recorded_by)
VALUES (1, DATE '2026-01-05', 250000, 'Mobile Money', 'gilbert_admin');

INSERT INTO payment (lease_id, payment_date, amount, payment_method, recorded_by)
VALUES (2, DATE '2026-02-05', 400000, 'Bank Transfer', 'gilbert_admin');

INSERT INTO maintenance_request (unit_id, tenant_id, description, status, assigned_staff)
VALUES (1, 1, 'Leaking kitchen tap', 'Open', 'Staff_Kevin');

INSERT INTO public_holiday (holiday_date, description)
VALUES (DATE '2026-07-01', 'Independence Day');

INSERT INTO public_holiday (holiday_date, description)
VALUES (DATE '2026-07-04', 'Liberation Day');

COMMIT;

-- ============================================================
-- VERIFY: confirm all 9 tables now exist
-- ============================================================
SELECT table_name FROM user_tables ORDER BY table_name;
